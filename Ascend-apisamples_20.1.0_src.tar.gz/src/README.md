EN|[CN](README.zh.md)
# Atlas Samples

Atlas Samples are the development samples that consist of function units isolated based on the Atlas development process, helping you understand the development process of Atlas 300 and 500. The function units include DVPP, process orchestration, inference, high-performance orchestration, and customized operator development.

## Copyright Description

Refer to [License.md](License.md)
