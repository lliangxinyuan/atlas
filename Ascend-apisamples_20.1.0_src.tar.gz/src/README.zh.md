中文|[英文](README.md)
# Atlas Samples

Atlas Samples是由Atlas软件开发流程中分解出的功能单元（DVPP、流程编排、推理、高性能编排、自定义算子开发等）组成的开发样例，通过一系列功能的开发样例，使用户更详细地了解Atlas 300、500的开发。


## 版权说明

请参阅 [License.md](License.md)
