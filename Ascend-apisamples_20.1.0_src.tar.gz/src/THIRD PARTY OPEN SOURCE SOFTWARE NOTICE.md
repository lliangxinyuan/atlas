**THIRD PARTY OPEN SOURCE SOFTWARE NOTICE**

Please note we provide an open source software notice for the third party open source software along with this software and/or this software component contributed by Huawei (in the following just “this SOFTWARE”). The open source software licenses are granted by the respective right holders.

**Warranty Disclaimer**

The open source software in this software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the applicable licenses for more details.

**Copyright Notice and License Texts**

**Software:** FFmpeg 4.2.1

**Copyright notice:**

Copyright (c) 2012 Martin Storsjo

Copyright (C) 2014 Red Hat, Inc.

Copyright (c) 2013 Nicolas George

Copyright (c) 2011 Anton Khirnov

Copyright (c) 2012 Stefano Sabatini

Copyright (c) 2002 Fabrice Bellard

Copyright (c) 2013 Michael Niedermayer

Copyright (c) 2013 James Almer

Copyright (c) 2008-2010 Stefano Sabatini

Copyright (c) 2005 Francois Revol

copyright (c) 2009 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2014 Martin Storsjo

Copyright (c) 2017 Paul B Mahol

Copyright (C) 2018 Michael Niedermayer (michaelni@gmx.at)

Copyright (c) 2007 Michael Niedermayer

Copyright (c) 2013 Stefano Sabatini

Copyright (c) 2015 Paul B Mahol

Copyright (c) 2003  The FFmpeg project

Copyright (c) 2009 Tobias Bindhammer

Copyright (c) 2008 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2009 Robert Swain ( rob opendot cl )

Copyright (c) 2015 Vesselin Bontchev

Copyright (c) 2001-2014, Jim Teeuwen

Copyright (c) 2007 Justin Ruggles <justin.ruggles@gmail.com>

Copyright (c) 2007-2008 Vladimir Voroshilov

Copyright (c) 2006 Baptiste Coudurier <baptiste.coudurier@smartjog.com>

Copyright (c) 2011 Justin Ruggles

Copyright (c) 2009 Benjamin Larsson

Copyright (c) 2012 Paul B Mahol

Copyright (c) 2006  Patrick Guimond

Copyright (c) 2016 Paul B Mahol

Copyright (c) 2000, 2001, 2002 Fabrice Bellard

Copyright (c) 2001 FFmpeg project

Copyright (c) 2009 Peter Ross

Copyright (c) 2007 Anssi Hannula <anssi.hannula@gmail.com>

Copyright (c) 2007 Benjamin Zores <ben@geexbox.org>

Copyright (c) 2014 Benoit Fouet

Copyright (c) 2015 Donny Yang

Copyright (C) 2017  Aurelien Jacobs <aurel@gnuage.org>

Copyright (c) 2012 Clément Bœsch

Copyright (c) 2000, 2001 Fabrice Bellard

Copyright (c) 2007 Reimar Doeffinger

Copyright (c) 2014 Alexandra Hájková

Copyright (c) 2008 Michael Niedermayer

Copyright (c) 2014 Clément Bœsch

Copyright (c) 2012 James Almer

Copyright (c) 2015 Zhang Rui <bbcallen@gmail.com>

Copyright (c) 2001 Fabrice Bellard

Copyright (c) 2009 Baptiste Coudurier <baptiste dot coudurier at gmail dot com>

Copyright (c) 2018 James Almer <jamrial@gmail.com>

Copyright (c) 2008 Aurelien Jacobs <aurel@gnuage.org>

copyright (c) 2001 Fabrice Bellard

Copyright (c) 2000 Fabrice Bellard

Copyright (c) 2000,2001 Fabrice Bellard

Copyright (c) 2012 AvxSynth Team

Copyright (c) 2006  Aurelien Jacobs <aurel@gnuage.org>

Copyright (c) 2007 Nicholas Tung

Copyright (c) 2008 Sisir Koppaka

Copyright (c) 2008-2010 Peter Ross (pross@xvid.org)

Copyright (c) 2009 Daniel Verkamp (daniel@drv.nu)

Copyright (c) 2010 Peter Ross <pross@xvid.org>

Copyright (c) 2012 Petri Hintukainen <phintuka <at> users.sourceforge.net>

Copyright (c) 2011 Konstantin Shishkov

Copyright (c) 2011,2014 Michael Niedermayer

Copyright (c) 2007  Justin Ruggles

Copyright (c) 2007 Justin Ruggles

Copyright (c) 2011 Carl Eugen Hoyos

Copyright (c) 2009  Stefan Gehrer <stefan.gehrer@gmx.de>

Copyright (c) 2009 Michael Tison

Copyright (c) 2011-2012 Paul B Mahol

Copyright (c) 2015 Rodger Combs

Copyright (c) 2010-2011 Peter Ross <pross@xvid.org>

Copyright (c) 2017 Tomas Härdin

Copyright (c) 2006 Steve Lhomme

Copyright (c) 2007 Wolfram Gloger

Copyright (c) 2010 Michele Orrù

Copyright (c) 2012 Nicolas George

Copyright (c) 2011 Martin Storsjo

Copyright (c) 2017 samsamsam@o2.pl based on HLS demux

Copyright (c) 2017 Steven Liu

Copyright (c) 2018 Akamai Technologies, Inc.

Copyright (c) 2005 Reimar Döffinger

Copyright (C) 2018 Huiwen Ren, <hwrenx@126.com>

Copyright (c) 2018 Paul B Mahol

Copyright (c) 2007 Marco Gerards <marco@gnu.org>

Copyright (c) 2008 Baptiste Coudurier <baptiste.coudurier@gmail.com>

Copyright (c) 2009 Reimar Döffinger <Reimar.Doeffinger@gmx.de>

Copyright (c) 2014 Peter Ross

Copyright (c) 2006 Gregory Montoir (cyx@users.sourceforge.net)

Copyright (c) 2014 Oleksij Rempel <linux@rempel-privat.de>

Copyright (c) 2008 Benjamin Larsson

Copyright (c) 2003 Roman Shaposhnik

Copyright (c) 2006 Daniel Maas <dmaas@maasdigital.com>

Copyright (c) 2015 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2016 Marton Balnt <cus@passwd.hu>

Copyright (c) 2007 Konstantin Shishkov

Copyright (c) 2007 Peter Ross

Copyright (c) 2004  The FFmpeg project

Copyright (c) 2006-2008 Peter Ross

Copyright (c) 2010 Anton Khirnov

Copyright (c) 2016 Jan Sebechlebsky

Copyright (c) 2010 Peter Ross

Copyright (c) 2017 Paras Chadha

Copyright (c) 2006-2009 Justin Ruggles

Copyright (C) 2009 Justin Ruggles

Copyright (c) 2003 The FFmpeg project

Copyright (c) 2006 The FFmpeg Project

Copyright (c) 2003 The FFmpeg Project

Copyright (c) 2013 Lukasz Marek <lukasz.m.luki@gmail.com>

Copyright (c) 2010 Martin Storsjo

Copyright (c) 2010 Mohamed Naufal Basheer

Copyright 2017 Carl Eugen Hoyos

Copyright (c) 2011 Vladimir Voroshilov

Copyright (c) 2012 Vitaliy E Sugrobov

Copyright (c) 2009 Toshimitsu Kimura

based on libavformat/http.c, Copyright (c) 2000, 2001 Fabrice Bellard

Copyright (c) 2006 Reimar Doeffinger

copyright (c) 2006 Reimar Doeffinger

Copyright (c) 2006 SmartJog S.A., Baptiste Coudurier <baptiste dot coudurier at smartjog dot com>

Copyright (c) 2009 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2009 Reimar Döffinger, based on crcenc (c) 2002 Fabrice Bellard

Copyright (c) 2019 Paul B Mahol

Copyright (c) 2013 Martin Storsjo

Copyright (c) 2014 Tim Walker <tdskywalker@gmail.com>

Copyright (c) 2013 Dirk Farin <dirk.farin@gmail.com>

Copyright (c) 2013 Anssi Hannula

Copyright (c) 2012, Luca Barbato

Copyright (c) 2017 Akamai Technologies, Inc.

Copyright (c) 2012 David Kment

Copyright (c) 2010 Josh Allmann

Copyright (c) 2014 Marvin Scholz

Copyright (c) 2011 Peter Ross (pross@xvid.org)

Copyright (c) 2012 Michael Bradshaw <mjbshaw gmail com>

Copyright (c) 2003 Fabrice Bellard

Copyright (c) 2007 Vitor Sessak

Copyright (c) 2008 Jaikrishnan Menon <realityman@gmx.net>

Copyright (c) 2010 Sebastian Vater <cdgs.basty@googlemail.com>

Copyright (c) 2019 Swaraj Hota

Copyright (c) 2004 Michael Niedermayer

Copyright (c) 2014 Michael Niedermayer

Copyright (c) 2005 Alex Beregszaszi

Copyright (c) 2002 Francois Revol <revol@free.fr>

Copyright (c) 2006 Baptiste Coudurier <baptiste.coudurier@free.fr>

copyright (c) 2002 Francois Revol <revol@free.fr>

copyright (c) 2006 Baptiste Coudurier <baptiste.coudurier@free.fr>

Copyright (c) 2009 Michael Niedermayer

Copyright (c) 2010 David Conrad

Copyright (c) 2010 Reimar Döffinger

Copyright (c) 2005, 2011 Peter Ross <pross@xvid.org>

Copyright (c) 2011 Kieran Kunhya <kieran@kunhya.com>

Copyright (c) 2016 Josh de Kock

Copyright (c) 2010 Howard Chu

Copyright (c) 2014 Lukasz Marek <lukasz.m.luki@gmail.com>

Copyright (c) 2008 Ivo van Poorten

Copyright (c) 2014 StarBrilliant <m13253@hotmail.com>

Copyright (c) 2010 Tomas Härdin

Copyright (c) 2006  Thijs Vermeir <thijs.vermeir@barco.com>

Copyright (c) 2003-2004 The FFmpeg project

Copyright (c) 2003-2008 The FFmpeg Project

Copyright (c) 2007 David Conrad

Copyright (c) 2010 Mans Rullgard

copyright (c) 2009 Michael Niedermayer

Copyright (c) 2010  Aurelien Jacobs <aurel@gnuage.org>

Copyright (c) 2012  Clément Bœsch <u pkh me>

Copyright (c) 2016 Ståle Kristoffersen

Copyright (c) 2009 David Conrad

Copyright (c) 2015 Carl Eugen Hoyos

Copyright (c) 2006 Peter Ross

Copyright (c) 2005 Vidar Madsen

Copyright (c) 2006,2007 Ryan Martell

Copyright (c) 2007 Björn Axelsson

Copyright (c) 2010 Zhentan Feng <spyfeng at gmail dot com>

Copyright (c) 2003 Thomas Raivio

Copyright (c) 2004 Gildas Bazin <gbazin at videolan dot org>

Copyright (c) 2015 Eran Kornblau <erankor at gmail dot com>

Copyright (c) 2006 Konstantin Shishkov

Copyright (c) 2002-2003 Fabrice Bellard

Copyright (c) 2006 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2000, 2001, 2002, 2003 Fabrice Bellard

Copyright (c) 2015 Luca Barbato

Copyright (C) 2008  Ramiro Polla

Copyright (c) 2006 Reynaldo H. Verdejo Pinochet

Copyright (c) 2012 Peter Ross

Copyright (c) 2008 Gregory Montoir (cyx@users.sourceforge.net)

Copyright (c) 2008 GUCAS, Zhentan Feng <spyfeng at gmail dot com>

Copyright (c) 2008 Baptiste Coudurier <baptiste dot coudurier at gmail dot com>

Copyright (c) 2010 Anatoly Nenashev

Copyright (c) 2009  Nicolas Martin (martinic at iro dot umontreal dot ca)

Copyright (c) 2007 The FFmpeg Project

Copyright (c) 2004 The FFmpeg Project

Copyright (c) 2004-2007 Michael Niedermayer

Copyright (c) 2006 Michael Niedermayer

Copyright (c) 2004-2006 Michael Niedermayer

Copyright (c) 2003 Alex Beregszaszi

Copyright (C) 2005  Michael Ahlberg, Måns Rullgård

Copyright (c) 2007 Baptiste Coudurier <baptiste dot coudurier at free dot fr>

Copyright (c) 2011 Nicolas George

Copyright (C) 2015 Rostislav Pehlivanov <atomnuker gmail com>

Copyright (C) 2015 Vittorio Giovara <vittorio.giovara gmail com>

Copyright (C) 2008  David Conrad

Copyright (C) 2005  Matthieu CASTET

Copyright (C) 2010 David Conrad

Copyright (C) 2008  Reimar Döffinger

Copyright (C) 2005  Matthieu CASTET, Alex Beregszaszi

Copyright (C) 2013 James Almer

Copyright (c) 2008, 2013 Maxim Poliakovski

2008 Benjamin Larsson

2011 David Goldwich

Copyright (c) 2011 Michael Karcher

copyright (c) 2002 Francois Revol

copyright (c) 2000, 2001, 2002 Fabrice Bellard

Copyright (C) 2007  Aurelien Jacobs <aurel@gnuage.org>

Copyright (c) 2011 Reimar Döffinger

Copyright (c) 2016 Mobibase, France (http://www.mobibase.com)

Copyright (c) 2007, 2008 Ivo van Poorten

Copyright (c) 2009 Kenan Gillet

Copyright (c) 2015 Mats Peterson

Copyright (c) 2016 Michael Niedermayer

Copyright (c) 2007 Ronald S. Bultje

Copyright (c) 2007 Ronald S. Bultje <rbultje@ronald.bitfreak.net>

copyright (c) 2000 Fabrice Bellard

Copyright (c) 2008 Sascha Sommer (saschasommer@freenet.de)

Copyright (c) 2009  Aurelien Jacobs <aurel@gnuage.org>

Copyright (c) 2007 Christian Ohm, 2008 Eli Friedman

Copyright (c) 2010 Rafael Carre

Copyright (c) 2001 Fabrice Bellard (original AU code)

Copyright (c) 2009 Konstantin Shishkov

Copyright (c) 2008-2009 Andrej Stepanchuk

Copyright (c) 2009-2010 Howard Chu

Copyright (c) 2012 Samuel Pitoiset

Copyright (c) 2009 Andrej Stepanchuk

Copyright (c) 2006 Ryan Martell <rdm4@martellventures.com>

Copyright (c) 2015 Gilles Chanteperdrix <gch@xenomai.org>

Copyright (c) 2008 Ronald S. Bultje

Copyright (c) 2015 Thomas Volkert <thomas@homer-conferencing.com>

Copyright (c) 2011 Miroslav Slugeň <Thunder.m@seznam.cz>

Copyright (c) 2014 Thomas Volkert <thomas@homer-conferencing.com>

Copyright 2005 Wim Taymans

Copyright 2007 Edward Hervey

Copyright 2007 Nokia Corporation

Copyright 2007 Collabora Ltd, Philippe Kalaf

Copyright 2010 Mark Nauwelaerts

Copyright (c) 2006 Ryan Martell

Copyright (c) 2010 Fabrice Bellard

Copyright (c) 2010 Ronald S. Bultje

Copyright (c) 2009 Ronald S. Bultje

Copyright (c) 2016 Savoir-faire Linux, Inc

Copyright (c) 2016 Thomas Volkert <thomas@netzeal.de>

Copyright (c) 2009 Colin McQuillian

copyright (c) 2007 Luca Abeni

Copyright (c) 2007 Luca Abeni

Copyright (c) 2009 Martin Storsjo

Copyright (c) 2009 Luca Abeni

Copyright (c) 2008 Luca Abeni

Copyright (c) 2011 Juan Carlos Rodriguez <ing.juancarlosrodriguez@hotmail.com>

copyright (c) 2002 Fabrice Bellard

copyright (c) 2014 Samsung Electronics. All rights reserved.

Copyright (C) 2017 foo86

Copyright (c) 2012 Luca Barbato

Copyright (c) 2003 International Business Machines, Corp.

Copyright (c) 2014 Paul B Mahol

Copyright (C) 2003 The FFmpeg project

Copyright (C) 2018 Misty De Meo

Copyright (c) 2011, Luca Barbato

Copyright (c) 2004 The FFmpeg project

Copyright (c) 2011 Paul B Mahol

Copyright (c) 2006 Cyril Zorin

Copyright Konstantin Shishkov

Copyright (c) 2009 Daniel Verkamp <daniel@drv.nu>

Copyright (c) 2008 robs@users.sourceforge.net

Copyright (c) 2009 Bartlomiej Wolowiec

Copyright (c) 2010 Anssi Hannula <anssi.hannula at iki.fi>

Copyright (c) 2010 Anssi Hannula

Copyright (c) 2010 Carl Eugen Hoyos

Copyright (c) 2015  Clément Bœsch <u pkh me>

Copyright (c) 2012  Nicolas George <nicolas.george@normalesup.org>

Copyright (c) 2014 Eejya Singh

Copyright (c) 2014 Nicolas George

Copyright (c) 2012-2013 Clément Bœsch <u pkh me>

Copyright (c) 2014 Petri Hintukainen <phintuka@users.sourceforge.net>

Copyright (c) 2003 Tinic Uro

Copyright (c) 2016 Michael Niedermayer <michael@niedermayer.cc>

Copyright (c) 2007 Marco Gerards

Copyright (c) 2017 sfan5 <sfan5@live.de>

Copyright (c) 2018 Thomas Volkert

Copyright (c) 2015 Hendrik Leppkes

Copyright (c) 2009 Daniel Verkamp <daniel at drv.nu>

Copyright (c) 2006 Alex Beregszaszi

Copyright (c) 2016 James Almer

Copyright (c) 2007 Ivo van Poorten

Copyright (c) 2005 VLC authors and VideoLAN

Copyright (c) 2005 by Neal Symms (tivo@freakinzoo.com) - February 2005

Copyright (c) 2013 Luca Barbato

Copyright (c) 2012 Antti Seppälä

Copyright (c) 2015 Tiancheng "Timothy" Gu

Copyright (c) 2006, 2008 Konstantin Shishkov

Copyright (c) 2008 Konstantin Shishkov

Copyright (c) 2012 Krzysztof Klinikowski

Copyright (c) 2010 Andrzej Szombierski

based on vivparse Copyright (c) 2007 Måns Rullgård

Copyright (c) 2009 James Darnley

Copyright (c) 2016 Google Inc.

Copyright (c) 2016 KongQun Yang (kqyang@google.com)

Copyright (c) 2009 Vitor Sessak

Copyright (c) 2009 Daniel Verkamp

Copyright (c) 2001, 2002 Fabrice Bellard

Copyright (c) 2013 Daniel Verkamp <daniel@drv.nu>

Copyright (c) 2014 Georg Lippitsch <georg.lippitsch@gmx.at>

Copyright (c) 2014 Vignesh Venkatasubramanian

Copyright (c) 2015, Vignesh Venkatasubramanian

Copyright (c) 2013 Matthew Heaney

Copyright (c) 2011 Zhentan Feng <spyfeng at gmail dot com>

Copyright (c) 2011 Peter Ross <pross@xvid.org>

Copyright (c) 2006,2011 Konstantin Shishkov

Copyright (c) 2013 Konstantin Shishkov <kostya.shishkov@gmail.com>

Copyright (c) 2008 Robert Marston

Copyright (c) 2011 Sven Hesse <drmccoy@drmccoy.de>

Copyright (c) 2011 Matthew Hoops <clone2727@gmail.com>

Copyright (c) 2011 Max Horn

Copyright (C) 2010 Mohamed Naufal Basheer <naufal11@gmail.com>

Copyright (C) 2009 Thomas P. Higdon <thomas.p.higdon@gmail.com>

Copyright (c) 2001, 2002, 2003 Fabrice Bellard

Copyright (c) 2015 Imagination Technologies Ltd

Copyright (c) 2012

Copyright (c) 2015 Manojkumar Bhosale (Manojkumar.Bhosale@imgtec.com)

Copyright (c) 2009 Mans Rullgard <mans@mansr.com>

Copyright (c) 2016 Loongson Technology Corporation Limited

Copyright (c) 2016 Zhou Xiaoyong <zhouxiaoyong@loongson.cn>

Copyright (C) 2001-2003 Michael Niedermayer (michaelni@gmx.at)

AltiVec optimizations (C) 2004 Romain Dolbeau <romain@dolbeau.org>

based on code by Copyright (C) 2001-2003 Michael Niedermayer (michaelni@gmx.at)

Copyright (C) 2001-2002 Michael Niedermayer (michaelni@gmx.at)

Copyright (C) 2013 Xiaolei Yu <dreifachstein@gmail.com>

Copyright (c) 2004-2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2009 Stefano Sabatini

Copyright (c) 2007 Bobby Bingham

Copyright (C) 2016 Rostislav Pehlivanov <atomnuker@gmail.com>

Copyright (c) 2003 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2006  Stefan Gehrer <stefan.gehrer@gmx.de>

Copyright (C) 2017 Ivan Kalvachev <ikalvachev@gmail.com>

Copyright (c) 2002-2004 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2007 Baptiste Coudurier <baptiste dot coudurier at smartjog dot com>

cleanup/optimizations are Copyright (c) 2002-2004 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2014 James Almer

Copyright (c) 2013 Diego Biurrun <diego@biurrun.de>

Copyright (c) 2004-2005 Michael Niedermayer, Loren Merritt

Copyright (c) 2010 Fiona Glaser <fiona@x264.com>

Copyright (c) 2011 Daniel Kang

Copyright (C) 2012 - 2013 Guillaume Martres

Copyright (C) 2013 - 2014 Pierre-Edouard Lepere

Copyright (c) 2013 Seppo Tomperi

Copyright (c) 2013 - 2014 Pierre-Edouard Lepere

Copyright (c) 2003-2004 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2009 Loren Merritt <lorenm@u.washington.edu>

Copyright (c) 2015 James Almer

Copyright (c) 2007 Loren Merritt

Copyright (c) 2006 Michael Niedermayer <michaelni@gmx.at> et al

Copyright (C) 2017 Rostislav Pehlivanov <atomnuker@gmail.com>

Copyright (c) 2009 Ramiro Polla

Copyright (c) 2010 Vitor Sessak

Copyright (c) 2002 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2008 Loren Merrit <lorenm@u.washington.edu>

Copyright (c) 2010-2011 Maxim Poliakovski

Copyright (C) 2012 Christophe Gisquet <christophe.gisquet@gmail.com>

Copyright (C) 2008-2010  Nokia Corporation

Copyright (C) 2004-2010  Marcel Holtmann <marcel@holtmann.org>

Copyright (C) 2004-2005  Henryk Ploetz <henryk@ploetzli.ch>

Copyright (C) 2005-2006  Brad Midgley <bmidgley@xmission.com>

Copyright (c) 2012 Christophe Gisquet <christophe.gisquet@gmail.com>

Copyright (c) 2005-2006 Robert Edele <yartrebo@earthlink.net>

Copyright (c) 2012-2014 Christophe Gisquet <christophe.gisquet@gmail.com>

Copyright (c) 2014-2016 James Almer

Copyright (c) 2007 Christophe GISQUET <christophe.gisquet@free.fr>

Copyright (C) 2002-2012 Michael Niedermayer

Copyright (C) 2012 Ronald S. Bultje

Copyright (C) 2006 Loren Merritt <lorenm@u.washington.edu>

Copyright (c) 2009 David Conrad <lessen42@gmail.com>

Copyright (C) 2006  Aurelien Jacobs <aurel@gnuage.org>

Copyright (C) 2010  Eli Friedman

Copyright (C) 2009  Sebastien Lucas <sebastien.lucas@gmail.com>

Copyright (C) 2009  Zuxy Meng <zuxy.meng@gmail.com>

Copyright (c) 2010 Ronald S. Bultje <rsbultje@gmail.com>

Copyright (c) 2013 Ronald S. Bultje <rsbultje gmail com>

Copyright (c) 2012 Ronald S. Bultje <rsbultje@gmail.com>

Copyright (c) 2015 Henrik Gramner

Copyright (c) 2008 Loren Merritt

Copyright (c) 2017 James Almer

Copyright (c) 2015 Janne Grunau

Copyright (c) 2016 Martin Storsjo

Copyright (c) 2016 Alexandra Hájková

Copyright (c) 2018 Yingming Fan <yingmingfan@gmail.com>

Copyright (c) 2017 Jokyo Images

Copyright (c) 2019 James Darnley

Copyright (c) 2016 Tiancheng "Timothy" Gu

Copyright (c) 2016 Ronald S. Bultje <rsbultje@gmail.com>

Copyright (c) 2018 Clément Bœsch <u pkh me>

Copyright (c) 2015 Ronald S. Bultje <rsbultje@gmail.com>

Copyright (c) 2012 Justin Ruggles <justin.ruggles@gmail.com>

Copyright 2003 Kevin Atkinson

copyright (c) 2006 Michael Niedermayer <michaelni@gmx.at>

(c)1997-99 by H. Dietz and R. Fisher

Copyright (c) 2010 Alexander Strange <astrange@ithinksw.com>

Copyright (c) 2013 Loren Merritt

Copyright (c) 2008 Ramiro Polla <ramiro.polla@gmail.com>

Copyright (c) 2014 Peter Meerwald <pmeerw@pmeerw.net>

copyright (c) Sebastien Bechet <s.bechet@av7.net>

Copyright (c) 2003-2013 Loren Merritt

Copyright (c) 2007 Luca Barbato <luzero@gentoo.org>

Copyright (c) 2002 Brian Foley

Copyright (c) 2002 Dieter Shirley

Copyright (c) 2003-2004 Romain Dolbeau <romain@dolbeau.org>

Copyright (C) 2003  James Klicman <james@klicman.org>

Copyright (c) 2009 Loren Merritt

Copyright (c) 2014 Rong Yan

Copyright (c) 2014 Rong Yan  Copyright (c) 2009 Loren Merritt

Copyright (c) 2006 Luca Barbato <luzero@gentoo.org>

Copyright (c) 2004 Romain Dolbeau <romain@dolbeau.org>

Copyright (c) Alexandra Hajkova

Copyright (c) 2001 Michel Lespinasse

Copyright (c) 2003 Romain Dolbeau <romain@dolbeau.org>

Copyright (c) 2003-2004 Romain Dolbeau

Copyright (C) 2009 David Conrad

Copyright (c) 2008 Mans Rullgard <mans@mansr.com>

Copyright (c) 2015 Janne Grunau <janne-libav@jannau.net>

Copyright (C) 2011 Michael Niedermayer (michaelni@gmx.at)

Copyright (c) 1994-2012 by the Xiph.Org Foundation and contributors

Copyright (c) 2004 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2015 Parag Salasakar (parag.salasakar@imgtec.com)

Copyright (c) 2015 Loongson Technology Corporation Limited

Copyright (c) 2015 Zhou Xiaoyong <zhouxiaoyong@loongson.cn>

Copyright (c) 2018 Loongson Technology Corporation Limited

Copyright (c) 2018 Shiyou Yin <yinshiyou-hf@loongson.cn>

Copyright (c) 2015 Shivraj Patil (Shivraj.Patil@imgtec.com)

Copyright (c) 2015 - 2017 Shivraj Patil (Shivraj.Patil@imgtec.com)

Copyright (c) 2015 Parag Salasakar (Parag.Salasakar@imgtec.com)

Copyright (c) 2015 - 2017 Parag Salasakar (Parag.Salasakar@imgtec.com)

Copyright (c) 2015 - 2017 Manojkumar Bhosale (Manojkumar.Bhosale@imgtec.com)

Copyright (c) 2015 -2017 Parag Salasakar (Parag.Salasakar@imgtec.com)

Copyright (c) 2019 Shiyou Yin (yinshiyou-hf@loongson.cn)

Copyright (c) 2015 -2017 Manojkumar Bhosale (Manojkumar.Bhosale@imgtec.com)

Copyright (c) 2017 Kaustubh Raste (kaustubh.raste@imgtec.com)

Copyright (c) 2018 gxw <guxiwei-hf@loongson.cn>

Copyright (c) 2019 gxw <guxiwei-hf@loongson.cn>

Copyright (c) 2002 Falk Hueffner <falk@debian.org>

copyright (c) 2002 Falk Hueffner <falk@debian.org>

Copyright (c) 2001 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2015 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2011-2014 Peter Ross <pross@xvid.org>

Copyright (C) 2015 Pedro Arthur <bygrandao@gmail.com>

Copyright (C) 2001-2011 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2001-2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2001-2003 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2009 Konstantin Shishkov

Copyright (C) 2010 Rémi Denis-Courmont

Copyright (c) 2011 Stefano Sabatini

Copyright (c) 2008 Rob Sykes

Copyright (c) Markus Schmidt and Christian Holschuh

Copyright (c) 2013 Paul B Mahol

Copyright (c) 2001-2010 Krzysztof Foltman, Markus Schmidt, Thor Harald Johansen, Damien Zammit and others

Copyright (c) 2013-2015 Paul B Mahol

Copyright (c) 2018 The FFmpeg Project

Copyright (c) 2011 Mina Nagy Zaki

Copyright (C) 2001-2010 Krzysztof Foltman, Markus Schmidt, Thor Harald Johansen, Damien Zammit

Copyright (C) 2001-2010 Krzysztof Foltman, Markus Schmidt, Thor Harald Johansen and others

Copyright (c) 2011 Nicolas George <nicolas.george@normalesup.org>

Copyright (c) 2001-2010 Krzysztof Foltman, Markus Schmidt, Thor Harald Johansen and others

Copyright (c) 2010 S.N. Hemanth Meenakshisundaram <smeenaks@ucsd.edu>

Copyright (c) 2012 Michael Niedermayer

Copyright (c) 2012 Andrey Utkin

Copyright (c) 2019 The FFmpeg Project

Copyright (c) 2009 Rob Sykes <robs@users.sourceforge.net>

Copyright (c) 2012 Pavel Koshevoy <pkoshevoy at gmail dot com>

Copyright (c) 2006-2008 Rob Sykes <robs@users.sourceforge.net>

1-pole filters based on code (c) 2000 Chris Bagwell <cbagwell@sprynet.com>

Copyright (c) 2012 Google, Inc.

Copyright (c) 1998 Juergen Mueller And Sundry Contributors

Copyright (c) 1999 Chris Bagwell

Copyright (c) 1999 Nick Bailey

Copyright (c) 2007 Rob Sykes <robs@users.sourceforge.net>

Copyright (c) 2014 Andrew Kelley

Copyright (c) 2001-2010 Krzysztof Foltman, Markus Schmidt, Thor Harald Johansen, Vladimir Sadovnikov and others

Copyright (c) 2016 The FFmpeg Project

Copyright (c) 2000 Chris Ausbrooks <weed@bucket.pp.ualr.edu>

Copyright (c) 2000 Fabien COELHO <fabien@coelho.net>

Copyright (c) 2018 Chris Johnson

Copyright (c) 2015 LoRdMuldeR <mulder2@gmx.de>. Some rights reserved.

Copyright (c) 2000 Edward Beingessner And Sundry Contributors.

Copyright (c) 2015 The FFmpeg Project

Copyright (c) 2016 Muhammad Faiz <mfcc64@gmail.com>

Copyright (c) 2006 Rob Sykes <robs@users.sourceforge.net>

Copyright (c) 2001-2010 Vladimir Sadovnikov

Copyright (C) 2010, Chris Moeller,

All rights reserved.

Copyright (C) 2017 Paul B Mahol

Copyright (C) 2013-2015 Andreas Fuchs, Wolfgang Hrauda

Copyright (c) 2016 Kyle Swanson <k@ylo.ph>.

Copyright (c) 2007-2016 David Robillard <http://drobilla.net>

COpyright (c) 2002 Daniel Pouzzner

Copyright (c) 2002 Anders Johansson <ajh@atri.curtin.edu.au>

Copyright (c) 2011 Clément Bœsch <u pkh me>

Copyright (c) 1998 - 2009 Conifer Software

Copyright (c) 2012 Clément Bœsch <u pkh me>

Copyright (c) 2001 Heikki Leinonen

Copyright (c) 2001 Chris Bagwell

Copyright (c) 2003 Donnie Smith

Copyright (C) 2013-2015 Andreas Fuchs, Wolfgang Hrauda,

Acoustics Research Institute (ARI), Vienna, Austria

Copyright (C) 2001-2010 Krzysztof Foltman, Markus Schmidt, Thor Harald Johansen

Copyright (C) 2012 VLC authors and VideoLAN

Copyright (c) 2002 Naoki Shibata

Copyright (c) 2015 Kyle Swanson <k@ylo.ph>.

Copyright (c) 2008 Vitor Sessak

Copyright 2010 S.N. Hemanth Meenakshisundaram <smeenaks ucsd edu>

Copyright 2010 Stefano Sabatini <stefano.sabatini-lala poste it>

Copyright (c) 2008-2009 Rob Sykes <robs@users.sourceforge.net>

Copyright (c) Stefano Sabatini | stefasab at gmail.com

Copyright (c) S.N. Hemanth Meenakshisundaram | smeenaks at ucsd.edu

Copyright (c) 2014-2015 Muhammad Faiz <mfcc64@gmail.com>

Copyright (c) 2015 Muhammad Faiz <mfcc64@gmail.com>

Copyright (c) 2012-2013 Clément Bœsch

Copyright (c) 2013 Rudolf Polzer <divverent@xonotic.org>

Copyright (c) 2005 Robert Edele <yartrebo@earthlink.net>

Copyright (c) 2018 Danil Iashchenko

Copyright (C) 2013 Wei Gao <weigao@multicorewareinc.com>

Copyright (C) 2013 Lenny Wang

Copyright (c) 2018 Sergey Lavrushkin

Copyright 2011 Stefano Sabatini <stefano.sabatini-lala poste it>

Copyright 2012 Nicolas George <nicolas.george normalesup org>

Copyright (c) 2011 Jan Kokemüller

Copyright (c) 2015 Matthieu Bouron <matthieu.bouron stupeflix.com>

Copyright (c) 2016 Nicolas George

Copyright (c) 2018 Marton Balint

Copyright (c) 2013 Clément Bœsch

Copyright (c) 2015 Nicolas George

Copyright (c) 2015 Derek Buitenhuis

Copyright (c) 2011 Pascal Getreuer

Copyright (c) 2010 Nolan Lum <nol888@gmail.com>

Copyright (c) 2007 Benoit Fouet

Copyright (c) 2010 Stefano Sabatini

Copyright 2012 Stefano Sabatini <stefasab gmail com>

Copyright (c) 2016 Davinder Singh (DSM) <ds.mudhar<@gmail.com>

Copyright (c) 2015 James Darnley

Copyright (c) 2008 Victor Paesa

Copyright (c) 2017 Gerion Entrup

Copyright (c) 2010 Baptiste Coudurier

Copyright (c) 2003 Michael Zucchi <notzed@ximian.com>

Copyright (C) 2010 Georg Martius <georg.martius@web.de>

Copyright (C) 2010 Daniel G. Taylor <dan@programmer-art.org>

Copyright (c) 2012 Steven Robertson

Copyright (c) 2010 Bobby Bingham

Copyright (c) 2018 Dylan Fernando

Copyright (c) 2006 Ivo van Poorten

Copyright (c) 2006 Julian Hall

Copyright (c) 2002-2003 Brian J. Murrell

Copyright (c) 2015-2016 mawen1250

Copyright (C) 2016 Thomas Mundt <loudmax@yahoo.de>

Copyright (C) 2006-2011 Michael Niedermayer <michaelni@gmx.at>

2010      James Darnley <james.darnley@gmail.com>

Copyright (C) 2012 British Broadcasting Corporation, All Rights Reserved

Copyright (c) 2015 Timo Rothenpieler <timo@rothenpieler.org>

Copyright (c) 2000 John Walker

Copyright (c) 2014 Clément Bœsch <u pkh me>

Copyright (c) 2018 Mina Sami

Copyright (C) 2006-2007 Kevin Stone

Copyright (c) 2012-2013 Oka Motofumi (chikuzen.mo at gmail dot com)

Copyright (c) 2014-2015 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2002 A'rpi

Copyright (c) 2013-2014 Clément Bœsch

Copyright (c) 2015 Niklas Haas

Copyright (c) 2012 Fredrik Mellbin

Copyright (c) 2014 Nicholas Robbins

Copyright (c) 2002 Jindrich Makovicka <makovick@gmail.com>

Copyright (c) 2013, 2015 Jean Delvare <jdelvare@suse.com>

Copyright (c) 2019 Xuewei Meng

Copyright (c) 2015 Himangi Saraogi <himangi774@gmail.com>

Copyright (c) 2008 Affine Systems, Inc (Michael Sullivan, Bobby Impollonia)

Copyright (c) 2013 Andrey Utkin <andrey.krieger.utkin gmail com>

Copyright (c) 2010 S.N. Hemanth Meenakshisundaram

Copyright (c) 2003 Gustavo Sverzut Barbieri <gsbarbieri@yahoo.com.br>

Copyright (c) 2012-2014 Clément Bœsch <u pkh me>

Copyright (c) 2014 James Darnley <james.darnley@gmail.com>

Copyright (c) 2015 Arwa Arif <arwaarif1994@gmail.com>

Copyright (c) 2010 Brandon Mintern

Copyright (c) 2003 Rich Felker

Copyright (c) 2011 Mark Himsley

Copyright 2007 Bobby Bingham

Copyright 2012 Robert Nagy <ronag89 gmail com>

Copyright 2012 Anton Khirnov <anton khirnov net>

Copyright 2018 Calvin Walton <calvin.walton@kepstin.ca>

Copyright (c) 2013 Vittorio Giovara

Copyright (C) 2012 Mark Himsley

getscenescore() Copyright (c) 2011 Stefano Sabatini

Copyright (C) 2005 Nikolaj Poroshin <porosh3@psu.ru>

Copyright (c) 2014 Arwa Arif <arwaarif1994@gmail.com>

Copyright (C) 2006 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2012 Clément Bœsch <u pkh me>

Copyright (c) 2012 Jeremy Tran

Copyright (c) 2001 Donald A. Graft

Copyright (c) 2012-2013 Paul B Mahol

Copyright (c) 2003 Daniel Moreno <comac AT comac DOT darktech DOT org>

Copyright (c) 2012 Loren Merritt

Copyright (c) 2003 Michael Niedermayer

Copyright (c) 2013 Oka Motofumi (chikuzen.mo at gmail dot com)

Copyright (C) 2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2004 Tobias Diedrich

Copyright (c) 2003 Donald A. Graft

Copyright (C) 2007 Richard Spindler (author of frei0r plugin from which this was derived)

Copyright (C) 2014 Daniel Oberhoff

Copyright (C) 2007 by Andrew Zabolotny (author of lensfun, from which this filter derives from)

Copyright (C) 2018 Stephen Seo

Copyright (c) 2017 Ronald S. Bultje <rsbultje@gmail.com>

Copyright (c) 2017 Ashish Pratap Singh <ashk43712@gmail.com>

Copyright (c) 2016 Clément Bœsch <u pkh me>

Copyright (C) 2010-2011 Kevin Stone

Copyright (C) 2016 Paul B Mahol

Copyright (c) 2017 Richard Ling

Copyright (c) 2007 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2013 Clément Bœsch <u pkh me>

Copyright (c) 2008 vmrsss

Copyright (c) 2015 Stupeflix

Copyright (c) 2004 Ville Saari

Copyright (C) 2012 Clément Bœsch

Copyright (c) 2005 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2011 Roger Pau Monné <roger.pau@entel.upc.edu>

Copyright (C) 2004 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2016 Tobias Rapp

Copyright (c) 2016 Floris Sluiter

Copyright (c) 2012 Laurent de Soras

Copyright (c) 2013 Fredrik Mellbin

Copyright (c) 2003 Tobias Diedrich

Copyright (c) 2017, NVIDIA CORPORATION. All rights reserved.

Copyright (c) 2015-2016 Clément Bœsch <u pkh me>

Copyright (c) 2010 Mark Heath mjpeg0 @ silicontrip dot org

Copyright (c) 2014 Dave Rice @dericed

Copyright (c) 2015 Paul B. Mahol

Copyright (c) 2010 Gordon Schmidt <gordon.schmidt <at> s2000.tu-chemnitz.de>

Copyright (c) 2011 Baptiste Coudurier

Copyright (c) 2010 Niel van der Westhuizen <nielkie@gmail.com>

Copyright (c) 1997-2001 ZSNES Team ( zsknight@zsnes.com / demo@zsnes.com )

Copyright (c) 2012 Rudolf Polzer

Copyright (c) 2011 Smartjog S.A.S, Clément Bœsch <clement.boesch@smartjog.com>

Copyright (c) 2017 Thomas Mundt <tmundt75@gmail.com>

Copyright (c) 2017 Vittorio Giovara <vittorio.giovara@gmail.com>

Original copyright (c) 2002 Remi Guyomarch <rguyom@pobox.com>

Port copyright (c) 2010 Daniel G. Taylor <dan@programmer-art.org>

Copyright (c) 2003 LeFunGus, lefungus@altern.org

Copyright (c) 2013 Georg Martius <georg dot martius at web dot de>

Copyright (c) 2012-2016 Paul B Mahol

Copyright (c) 2013 Marton Balint

Copyright (c) 2011, 2012 Hyllian/Jararaca <sergiogdb@gmail.com>

Copyright (C) 2018 Philip Langdale <philipl@overt.org>

Copyright Stefano Sabatini <stefasab gmail com>

Copyright Vitor Sessak <vitor1001 gmail com>

Copyright (c) Stefano Sabatini 2011

Copyright (c) Stefano Sabatini 2010

Copyright (c) 2011 Michael Niedermayer

Copyright (c) 2007 Nicolas George <nicolas.george@normalesup.org>

Copyright (c) 2015 Martin Storsjo

Copyright (C) 2002 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2017 Clément Bœsch <u pkh me>

Copyright (C) 2003-2011 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2019 Rodger Combs

Copyright (C) 1995 Mark Adler

copyright (c) 2006 Mans Rullgard

copyright (c) 2007 Michael Niedermayer <michaelni@gmx.at>

copyright (c) 2015 Rodger Combs <rodger.combs@gmail.com>

copyright (c) 2010 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2005-2014 Rich Felker, et al.

Copyright (c) 2007 Mans Rullgard

Copyright (c) 2006 Ryan Martell. (rdm4@martellventures.com)

Copyright (c) 2014 Supraja Meedinti

Copyright (c) 2008 Peter Ross

Copyright (c) 2015 Kevin Wheatley <kevin.j.wheatley@gmail.com>

Copyright (c) 2014 Vittorio Giovara <vittorio.giovara@gmail.com>

Copyright (c) 2002-2006 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2006 Oded Shimon <ods15@ods15.dyndns.org>

copyright (c) 2016 Ganesh Ajjanagadde <gajjanag@gmail.com>

Copyright (c) 2006 Roman Shaposhnik

Copyright 2005 Balatoni Denes

Copyright 2006 Loren Merritt

Copyright (C) 2013 Reimar Döffinger <Reimar.Doeffinger@gmx.de>

Copyright (c) 2018 Mohammad Izadi <moh.izadi at gmail.com>

Copyright (C) 2012 Martin Storsjo

Copyright (c) 2011 Mans Rullgard

Copyright (c) 2010 Mans Rullgard <mans@mansr.com>

erf function: Copyright (c) 2006 John Maddock

Copyright (c) 2003 Michel Bardiaux

Copyright (c) 2003-2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2016 Neil Birkbeck <neil.birkbeck@gmail.com>

Copyright (c) 2005-2012 Michael Niedermayer <michaelni@gmx.at>

copyright (c) 2005-2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2006 Michael Niedermayer (michaelni@gmx.at)

Copyright (C) 2003-2005 by Christopher R. Hertel (crh@ubiqx.mn.org)

copyright (c) 2005 Michael Niedermayer <michaelni@gmx.at>

copyright (c) 2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2009 Baptiste Coudurier <baptiste.coudurier@gmail.com>

Copyright (C) 2007 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2013 James Almer <jamrial@gmail.com>

Copyright (c) 2016 Umair Khan <omerjerk@gmail.com>

Copyright (c) 2016 Vittorio Giovara <vittorio.giovara@gmail.com>

Copyright (c) 2013 Vittorio Giovara <vittorio.giovara@gmail.com>

Copyright (c) 2000-2003 Fabrice Bellard

Copyright (c) 2006 Smartjog S.A.S, Baptiste Coudurier <baptiste.coudurier@gmail.com>

Copyright (c) 2011-2012 Smartjog S.A.S, Clément Bœsch <clement.boesch@smartjog.com>

Copyright (c) 2015 Supraja Meedinti

Copyright (c) 2019 Lynne <dev@lynne.ee>

copyright (c) 2003 Fabrice Bellard

Copyright (c) 2014 James Yu <james.yu@linaro.org>

Copyright (c) 2008 Siarhei Siamashka <ssvb@users.sourceforge.net>

Copyright (C) 2012 Carl Eugen Hoyos

Copyright (C) 2003 Roberto Togni

Copyright (C) 2008 Jaikrishnan Menon

Copyright (C) 2011 Stefano Sabatini

Copyright (c) 2005-2006 Oded Shimon ( ods15 ods15 dyndns org )

Copyright (c) 2006-2007 Maxim Gavrilov ( maxim.gavrilov gmail com )

Copyright (C) 2008-2009 Konstantin Shishkov

Copyright (c) 2008-2013 Alex Converse <alex.converse@gmail.com>

Copyright (c) 2008-2010 Paul Kendall <paul@kcbbs.gen.nz>

Copyright (c) 2010      Janne Grunau <janne-libav@jannau.net>

Copyright (c) 2013

Copyright (C) 2008 Konstantin Shishkov

Copyright (c) 2015 Rostislav Pehlivanov ( atomnuker gmail com )

Copyright (C) 2015 Rostislav Pehlivanov

Copyright (C) 2015 Claudio Freire

Copyright (c) 2010 Alex Converse <alex.converse@gmail.com>

Copyright (c) 2012 Mans Rullgard

Copyright (c) 2008-2009 Robert Swain ( rob opendot cl )

Copyright (c) 2009-2010 Alex Converse <alex.converse@gmail.com>

Copyright (c) 2010      Alex Converse <alex.converse@gmail.com>

Copyright (c) 2014 Reimar Döffinger <Reimar.Doeffinger@gmx.de>

Copyright (c) 2009 Alex Converse <alex.converse@gmail.com>

Copyright (C) 2005 The FFmpeg project

Copyright (c) 2006 Kartikey Mahendra BHATT (bhattkm at gmail dot com)

Copyright (c) 2007-2008 Bartlomiej Wolowiec <bartek.wolowiec@gmail.com>

Copyright (c) 2007 Bartlomiej Wolowiec <bartek.wolowiec@gmail.com>

Copyright (c) 2006-2010 Justin Ruggles <justin.ruggles@gmail.com>

Copyright (c) 2006-2010 Prakash Punnoor <prakash@punnoor.de>

Copyright (c) 2011 Justin Ruggles <justin.ruggles@gmail.com>

Copyright (c) 2006-2011 Justin Ruggles <justin.ruggles@gmail.com>

Copyright (c) 2008 Vladimir Voroshilov

Copyright (c) 2001-2003 The FFmpeg project

Copyright (c) 2009 Alex Converse

Copyright (c) 2011  Justin Ruggles

Copyright (c) 2001,2003 BERO

Copyright (c) 2013 Konstantin Shishkov

Copyright (c) 2005 David Hammerton

Copyright (c) 2008  Jaikrishnan Menon <realityman@gmx.net>

Copyright (C) 2014 Vittorio Giovara <vittorio.giovara@gmail.com>

Copyright (c) 2009 Thilo Borgmann <thilo.borgmann at mail.de>

Copyright (c) 2010 Marcelo Galvao Povoa

Copyright (c) 2006-2007 Robert Swain

Copyright (c) 2009 Colin McQuillan

Copyright (c) 2006-2013 Maxim Poliakovski

Copyright (c) 2006-2008 Benjamin Larsson

Copyright (c) 2009-2013 Maxim Poliakovski

Copyright (c) 2009 Maxim Poliakovski

Copyright (c) 2006-2008 Maxim Poliakovski

Copyright (c) 2006-2007 Maxim Poliakovski

Copyright (c) 2006-2007 Benjamin Larsson

Copyright (c) 2010-2013 Maxim Poliakovski

Copyright (c) 2018 Rostislav Pehlivanov <atomnuker@gmail.com>

copyright (c) 2016 Rodger Combs

Copyright (c) 2012 Justin Ruggles

Copyright (c) 2019 James Almer <jamrial@gmail.com>

Copyright (C) 2018 James Almer <jamrial@gmail.com>

Copyright (c) 2014 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2018  Huiwen Ren <hwrenx@gmail.com>

Copyright (c) 2012 Carl Eugen Hoyos

Copyright (C) 2007 Nicholas Tung

Copyright (c) 2010 Thilo Borgmann <thilo.borgmann at mail.de>

Copyright (C) 2011 Peter Ross <pross@xvid.org>

Copyright (c) 2007-2011 Peter Ross (pross@xvid.org)

Copyright (c) 2010 Peter Ross (pross@xvid.org)

Copyright (c) 2017 Savoir-faire Linux, Inc

Copyright (c) 2010 Loren Merritt

Copyright (c) 2005 Mans Rullgard

Copyright (c) 2006, 2007 Michel Bardiaux

Copyright (c) 2012 Aleksi Nurmi

Copyright (c) 2012 Aneesh Dogra (lionaneesh) <lionaneesh@gmail.com>

Copyright (c) 2015 Vittorio Giovara <vittorio.giovara@gmail.com>

Copyright (c) 2016 Reimar Döffinger <Reimar.Doeffinger@gmx.de>

Copyright (c) 2010 Reimar Döffinger <Reimar.Doeffinger@gmx.de>

Copyright (c) 2015 Anshul Maheshwari

Copyright (c) 2015-2016 Kieran Kunhya <kieran@kunhya.com>

Copyright (c) 2015 Kieran Kunhya

Cinepak colorspace support (c) 2013 Rl, Aetey Global Technologies AB

Cinepak encoder (c) 2011 Tomas Härdin

(c) 2013, 2014 Rl, Aetey Global Technologies AB

Copyright (c) 2012-2018 Konstantin Shishkov

Copyright (c) 2012-2013 Derek Buitenhuis

Copyright (c) 2003 Sascha Sommer

Copyright (c) 2005 Benjamin Larsson

Copyright (c) 2010 Hans de Goede <hdegoede@redhat.com>

Copyright(C) 2010,2011 Philip Langdale <ffmpeg.philipl@overt.org>

Copyright (c) 2016 Timo Rothenpieler <timo@rothenpieler.org>

copyright (c) 2015 Steve Lhomme

copyright (c) 2009 Laurent Aimar

Copyright (C) 2004 Gildas Bazin

Copyright (C) 2004 Benjamin Zores

Copyright (C) 2006 Benjamin Larsson

Copyright (C) 2007 Konstantin Shishkov

Copyright (C) 2016 foo86

Copyright (C) 2017 Daniil Cherednik

Copyright (c) 2006 Benjamin Larsson

Copyright (C) 2008-2012 Alexander E. Patrakov

2010 Benjamin Larsson

2011 Xiang Wang

Copyright (c) 2009 Peter Ross <pross@xvid.org>

Copyright (C) 2009 Dylan Yudaken

Copyright (C) 2015 Vittorio Giovara <vittorio.giovara@gmail.com>

Copyright (C) 2007 Marco Gerards <marco@gnu.org>

Copyright (C) 2011 Jordi Ortiz

Copyright (C) 2016 Open Broadcast Systems Ltd.

Author    (C) 2016 Rostislav Pehlivanov <atomnuker@gmail.com>

Copyright (C) 2004-2010 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2008 David Conrad

Copyright (C) 2015 Open Broadcast Systems Ltd.

Author    (C) 2015 Rostislav Pehlivanov <atomnuker@gmail.com>

Copyright (c) 2007-2008 Marco Gerards <marco@gnu.org>

Copyright (c) 2008 BBC, Anuradha Suraparaju <asuraparaju@gmail.com>

Copyright (c) 2007 SmartJog S.A., Baptiste Coudurier <baptiste dot coudurier at smartjog dot com>

Copyright (c) 2011 MirriAd Ltd

Copyright (c) 2015 Christophe Gisquet

Copyright (c) 2008 Baptiste Coudurier <baptiste.coudurier@free.fr>

Copyright (c) 2009 Jimmy Christensen

Copyright (c) 2009, 2011 Sebastian Gesemann. All rights reserved.

Copyright (C) 2014 Oleksij Rempel <linux@rempel-privat.de>

Copyright (c) 2014 Peter Ross <pross@xvid.org>

Copyright (c) 2004 Roman Shaposhnik

Copyright (c) 2012 Laurent Aimar

Copyright (c) 2005 Fabrice Bellard

Copyright (c) 2005 Ian Caulfield

Copyright (c) 2005 Wolfram Gloger

Copyright (c) 2013 The FFmpeg Project

Copyright (C) 2018 Paul B Mahol

copyright (c) 2010 Laurent Aimar

copyright (c) 2014 - 2015 Hendrik Leppkes

copyright (c) 2015 Hendrik Leppkes

Copyright (c) 2008 Justin Ruggles

Copyright (c) 2007-2008 Peter Ross

Copyright (c) 2007-2008 Peter Ross <pross@xvid.org>

Copyright (c) 2007-2009 Peter Ross

Copyright (c) 2007-2009 Peter Ross <pross@xvid.org>

Copyright (C) 2007 Vitor Sessak <vitor1001@gmail.com>

Copyright (c) 2013 Maxim Poliakovski

Copyright (C) 2008 Eli Friedman (eli.friedman@gmail.com)

Copyright (C) 2008 Eli Friedman (eli.friedman <at> gmail.com)

Copyright (c) 2013 Thilo Borgmann <thilo.borgmann at mail.de>

Copyright (c) 2006 Industrial Light & Magic, a division of Lucas Digital Ltd. LLC

Copyright (c) 2015-2016 Matthieu Bouron <matthieu.bouron stupeflix.com>

Copyright (c) 2003-2013 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2003-2016 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2014 Konstantin Shishkov

Copyright (c) 2014 Derek Buitenhuis

Copyright (c) 2009 Justin Ruggles

Copyright (c) 2012 Mans Rullgard <mans@mansr.com>

Copyright (c) 2006  Justin Ruggles <justin.ruggles@gmail.com>

Copyright (c) 2010 Michael Chinen

Copyright (C) 2004 Alex Beregszaszi

Copyright (C) 2009 Joshua Warner

Copyright (C) 2003, 2004 The FFmpeg project

Copyright (c) 2012 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2005 Roine Gustafsson

Copyright (c) 2012 Konstantin Shishkov

Copyright (c) CMU 1993 Computer Science, Speech Group

Copyright (c) 2005 Steve Underwood <steveu at coppice.org>

Copyright (c) 2015 Peter Meerwald <pmeerw@pmeerw.net>

Copyright (c) Mohamed Naufal <naufal22@gmail.com>

Copyright (c) 2007 Vladimir Voroshilov

Copyright (c) 2015  Ganesh Ajjanagadde

Copyright (c) 2017 Konstantin Shishkov

Copyright (c) 2002 Francois Revol

Copyright (c) 2006 Baptiste Coudurier

Copyright (c) 2018 Bjorn Roche

Copyright (c) 2004 Alex Beregszaszi

Copyright (c) 2012  Justin Ruggles

Copyright (c) 2004 Maarten Daniels

copyright (c) 2002-2004 Michael Niedermayer <michaelni@gmx.at>

copyright (c) 2004 Maarten Daniels

Copyright (c) 2001 Juan J. Sierralta P

copyright (c) 2000,2001 Fabrice Bellard

copyright (c) 2001 Juan J. Sierralta P

Copyright (c) 2003-2011 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2003-2010 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2004-2011 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2007 Benoit Fouet <benoit.fouet@free.fr>

Copyright (C) 2015 Tom Butterworth <bangnoise@gmail.com>

Copyright (C) 2012 - 2013 Mickael Raulet

Copyright (C) 2012 - 2013 Gildas Cocherel

Copyright (C) 2012 - 2013 Wassim Hamidouche

Copyright (C) 2013 Seppo Tomperi

Copyright (C) 2013 Wassim Hamidouche

copyright (c) 2015 Anton Khirnov

Copyright (C) 2013 Anand Meher Kotra

Copyright (C) 2012 - 2103 Guillaume Martres

Copyright (C) 2012 - 2103 Mickael Raulet

Copyright (C) 2013 Vittorio Giovara

Copyright (c) 2017  Clément Bœsch <u@pkh.me>

Copyright (c) 2002-2014 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2013, The WebRTC project authors. All rights reserved.

Copyright (c) 2002-2004 Maxim Poliakovski

Copyright (c) 2007 Baptiste Coudurier

Copyright (c) 2005 Konstantin Shishkov

copyright (c) 2005 Konstantin Shishkov

Copyright (c) 2009 - 2011 Maxim Poliakovski

Copyright (c) 2009-2011 Maxim Poliakovski

Copyright (c) 2009-2010 Maxim Poliakovski

Copyright (c) 2004-2008 Marko Kreen

Copyright (c) 2008 Adam Gashlin

Copyright (c) 2007 Kamil Nowosad

Copyright (c) 2002-2007, Communications and Remote Sensing Laboratory, Universite catholique de Louvain (UCL), Belgium

Copyright (c) 2002-2007, Professor Benoit Macq

Copyright (c) 2001-2003, David Janssens

Copyright (c) 2002-2003, Yannick Verschueren

Copyright (c) 2003-2007, Francois-Olivier Devaux and Antonin Descampe

Copyright (c) 2005, Herve Drolon, FreeImage Team

Copyright (c) 2007, Callum Lerwick <seg@haxxed.com>

Copyright (c) 2013 Nicolas Bertrand <nicoinattendu@gmail.com>

Copyright (c) 2003-2004 Michael Niedermayer

Copyright (c) 2010 Daniel Verkamp

Copyright (c) 2009 Nathan Caldwell <saintdev (at) gmail.com>

copyright (c) 2008 Paul Kendall <paul@kcbbs.gen.nz>

Copyright (c) 2002-2004 Roberto Togni

Copyright (c) 2010, Google, Inc.

Copyright (c) 2019 Jan Ekström

Copyright (c) 2018 Ronald S. Bultje <rsbultje gmail com>

Copyright (c) 2018 James Almer <jamrial gmail com>

Copyright (C) 2018 Yiqun Xu, <yiqun.xu@vipl.ict.ac.cn>

Copyright (c) 2005 Alban Bedel <albeu@free.fr>

Copyright (c) 2006, 2007 Michel Bardiaux <mbardiaux@mediaxim.be>

Copyright (c) 2015 Tampere University of Technology

Copyright (c) 2002 Lennert Buytenhek <buytenh@gnu.org>

Copyright (C) 2014 Martin Storsjo

Copyright (C) 2016 Martin Storsjo

Copyright (c) 2009 Jaikrishnan Menon <realityman@gmx.net>

Copyright (c) 2011 Michael Bradshaw <mjbshaw gmail com>

Copyright (c) 2012 Nathan Caldwell

Copyright (c) 2017 Rostislav Pehlivanov <atomnuker@gmail.com>

Copyright (c) 2009 Xuggle Incorporated

Copyright (c) 2006 Paul Richards <paul.richards@gmail.com>

Copyright (c) 2002 Mark Hills <mark@pogo.org.uk>

Copyright (c) 2013 Guillaume Martres <smarter@ubuntu.com>

Copyright (c) 2013 Justin Ruggles <justin.ruggles@gmail.com>

Copyright (c) 2015 Urvang Joshi

Copyright (C) 2005  Mans Rullgard <mans@mansr.com>

Copyright (c) 2013-2014 Derek Buitenhuis

Copyright (C) 2010 Amanda, Y.N. Wu <amanda11192003@gmail.com>

Copyright (C) 2018 Yiqun Xu,   <yiqun.xu@vipl.ict.ac.cn>

Copyright (c) 2004 Adam Thayer <krevnik@comcast.net>

copyright (C) 2006 Corey Hickey

Copyright (c) 2005-2010, 2012 Wolfram Gloger

Copyright (c) 2007 Reynaldo H. Verdejo Pinochet (QCELP decoder)

Copyright (c) 2007 Bartlomiej Wolowiec

Copyright (c) 2002 Laszlo Torok <torokl@alpha.dfmk.hu>

Copyright (c) 2013-2014 Mozilla Corporation

Copyright (c) 2016 Matthieu Bouron <matthieu.bouron stupeflix.com>

Copyright (C) 2012, Collabora Ltd.

Copyright (C) 2012, Rafaël Carré <funman@videolanorg>

Copyright (C) 2015, Sebastian Dröge <sebastian@centricular.com>

Copyright (C) 2014-2015, Collabora Ltd.

Copyright (C) 2015, Edward Hervey

Copyright (C) 2015, Matthew Waters <matthew@centricular.com>

Copyright (C) 2005  Ole André Vadla Ravnås <oleavr@gmail.com>

Copyright (c) 2010 Adrian Daerr and Nicolas George

Copyright (c) 2002 Alex Beregszaszi

Copyright (c) 2016 William Ma, Ted Ying, Jerry Jiang

Copyright (c) 2007-2008 Ian Caulfield

2009 Ramiro Polla

Copyright (c) 2008 Ramiro Polla

Copyright (c) 2007 Ian Caulfield

Copyright (c) 2006,2008 Peter Ross

Copyright (c) 2002-2004 Michael Niedermayer

Copyright (c) 2008 Reimar Döffinger

Copyright (c) 2012  Philip Langdale <philipl@overt.org>

Copyright (c) 2007 Aurelien Jacobs <aurel@gnuage.org>

Copyright (c) 2002-2013 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2002-2010 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2015 Andreas Cadhalpun <Andreas.Cadhalpun@googlemail.com>

Copyright (c) 2010 Michael Niedermayer

Copyright (c) 2003 Ivan Kalvachev

copyright (c) 2007 Aurelien Jacobs <aurel@gnuage.org>

Copyright (C) 2012 Konstantin Shishkov

Copyright (c) 2011 Anatoly Nenashev

Copyright (c) 2007 a840bda5870ba11f19698ff6eb9581dfb0f95fa5,

539459aeb7d425140b62a3ec7dbf6dc8e408a306, and

520e17cd55896441042b14df2566a6eb610ed444

Copyright (c) 2007 Loic Minier <lool at dooz.org>

Copyright (c) 2008 Bartlomiej Wolowiec

(Copyright Joseph Artsimovich and UAB "DKD")

Copyright (c) 2016 Anton Khirnov

Copyright (c) 2017 Anton Khirnov

Copyright (c) 2017 Philip Langdale

Copyright (c) 2016 Timo Rothenpieler

Copyright (C) 2011 Martin Storsjo

Copyright (c) 2012 Andrew D'Addesio

Copyright (c) 2016 Rostislav Pehlivanov <atomnuker@gmail.com>

Copyright (c) 2007-2008 CSIRO

Copyright (c) 2007-2009 Xiph.Org Foundation

Copyright (c) 2008-2009 Gregory Maxwell

Copyright (c) 2002, 2003 Fabrice Bellard

Copyright (c) 2009, 2013 Christian Schmidt

Copyright (c) 2013 Christian Schmidt

Copyright (c) 2009 Stephen Backway

Copyright (c) 2009 Peter Holik

Copyright (c) 2010-2011 Elvis Presley

Copyright (c) 2011 Anatoliy Wasserman

Copyright (c) 2018 Jokyo Images

Copyright (c) 2016 Jokyo Images

Copyright (c) 2008 Alexander Strange (astrange@ithinksw.com)

copyright (c) 2004 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2007 Reynaldo H. Verdejo Pinochet

Copyright (c) 2003 Ewald Snel

Copyright (c) 2005 Roberto Togni

Copyright (c) 2004 Konstantin Shishkov

Copyright (c) 2015 Vittorio Giovara

copyright (c) 2013 Luca Barbato

copyright (c) 2015 Anton Khirnov <anton@khirnov.net>

copyright (c) 2013 Yukinori Yamazoe

Copyright (C) 2004 The FFmpeg project

Copyright (C) 2007 Clemens Fruhwirth

Copyright (C) 2007 Alexis Ballier

Copyright (c) 2009 Reimar Doeffinger <Reimar.Doeffinger@gmx.de>

Copyright (c) 2003 Nick Kurshev

Copyright (c) 2010 Francesco Lavra <francescolavra@interfree.it>

Copyright (c) 2009 Alex Converse <alex dot converse at gmail dot com>

Copyright (c) 2017 Lionel CHAZALLON

Copyright (c) 2000-2002 Fabrice Bellard

Copyright (C) 2008 Sascha Sommer (saschasommer@freenet.de)

Copyright (c) 2001-2003 BERO <bero@geocities.co.jp>

Copyright (c) 2011 Oskar Arvidsson

Copyright (c) 2005 Eric Lasota

Based on RoQ specs (c)2001 Tim Ferguson

Copyright (C) 2003 Mike Melanson

Copyright (C) 2003 Dr. Tim Ferguson

Copyright (C) 2004-2007 Eric Lasota

Based on RoQ specs (C) 2001 Tim Ferguson

copyright (c) 2007 Konstantin Shishkov

Copyright (c) 2007 Mike Melanson, Konstantin Shishkov

Copyright (c) 2011 Janne Grunau

Copyright (c) 2008 Laurent Aimar <fenrir@videolan.org>

Copyright (c) 2010 Google, Inc.

Copyright (c) 2013 Darryl Wallace <wallacdj@gmail.com>

Copyright (C) 2012-2013  Intel Corporation

Copyright (C) 2005-2008  Brad Midgley <bmidgley@xmission.com>

Copyright (C) 2012-2014  Intel Corporation

Copyright (c) 2005 Jeff Muizelaar

Copyright (c) 2008 Robert Swain

Copyright (c) 2013 Ash Hughes

Copyright (c) Luca Barbato

Copyright (C) 2006 Robert Edele <yartrebo@earthlink.net>

Copyright 2017 Steinar H. Gunderson

Copyright (c) 2002 The Xine project

Copyright (c) 2002 The FFmpeg project

SVQ1 Encoder (c) 2004 Mike Melanson <melanson@pcisys.net>

Copyright (C) 2004 Mike Melanson <melanson@pcisys.net>

copyright (c) 2008 Michael Niedermayer <michaelni@gmx.at>

Copyright (C) 2009 Benjamin Dobell, Glass Echidna

Copyright (C) 2012 Matthäus G. "Anteru" Chajdas (http://anteru.net)

Copyright (c) 2008 Alexander Strange <astrange@ithinksw.com>

Copyright (c) 2011 Thomas Kuehnel

Copyright (C) 2003 Alex Beregszaszi & Mike Melanson

for decoding algorithms are not necessarily copyrightable.

Copyright (C) 2004 Konstantin Shishkov

copyright (C) 2004 Konstantin Shishkov

Copyright (c) 2012 Jan Ekström

Copyright (C) 2009 Michael Niedermayer <michaelni@gmx.at>

Copyright (c) 2011 Derek Buitenhuis

Copyright (C) 2017 Alexis Ballier <aballier@gentoo.org>

Copyright (C) 2017 Jorge Ramirez <jorge.ramirez-ortiz@linaro.org>

Copyright (C) 2008-2009 Splitted-Desktop Systems

Copyright (C) 2015 Timo Rothenpieler <timo@rothenpieler.org>

Copyright (c) 2011 Mashiat Sarker Shakkhar

Copyright (c) 2006-2007 Konstantin Shishkov

Partly based on vc9.c (c) 2005 Anonymous, Alex Beregszaszi, Michael Niedermayer

copyright (c) 2006 Konstantin Shishkov

copyright (c) 2011 Mashiat Sarker Shakkhar

(c) 2005 anonymous, Alex Beregszaszi, Michael Niedermayer

Copyright (c) 2008 NVIDIA

Copyright (C) 2008 NVIDIA

Copyright (c) 2013 Rémi Denis-Courmont

Copyright (c) 2013 Philip Langdale

Copyright (c) 2002-2012 Michael Niedermayer

copyright (c) 2012 Sebastien Zwickert

copyright (c) 2015 Rick Kern <kernrj@gmail.com>

copyright (c) 2006 Oded Shimon <ods15@ods15.dyndns.org>

copyright (c) 2005 Denes Balatoni ( dbalatoni programozo hu )

Copyright (C) 2003-2004 The FFmpeg project

Copyright (C) 2019 Peter Ross

Copyright (C) 2008 Michael Niedermayer

Copyright (c) 2006 Aurelien Jacobs <aurel@gnuage.org>

Copyright (C) 2010 Ronald S. Bultje

Copyright (C) 2010 Fiona Glaser

Copyright (C) 2012 Daniel Kang

Copyright (C) 2014 Peter Ross

Copyright (C) 2013 Ronald S. Bultje <rsbultje gmail com>

Copyright (C) 2013 Clément Bœsch <u pkh me>

Copyright (c) 2013 Aneesh Dogra <aneesh@sugarlabs.org>

Copyright (c) 2014  Aman Gupta <ffmpeg@tmm1.net>

Copyright (c) 2002-2007 The FFmpeg Project

copyright (c) 2002 The FFmpeg Project

Copyright (c) 2002 The FFmpeg Project

Copyright (c) 2007 Baptiste Coudurier, Benjamin Larsson, Ulion

Copyright (c) 2008 - 2011 Sascha Sommer, Benjamin Larsson

Copyright (c) 2011 Andreas Öman

Copyright (c) 2011 - 2012 Mashiat Sarker Shakkhar

Copyright (c) 2008 - 2009 Sascha Sommer

Copyright (c) 1990 James Ashton - Sydney University

Copyright (C) 2007 The FFmpeg Project

Copyright (c) 2007 Reimar Döffinger

Copyright (c) 2005 DivX, Inc.

Copyright (c) 2009 Bjorn Axelsson

Copyright (C) 2006-2011 Xvid Solutions GmbH

Copyright (C) 2003 Ivan Kalvachev

Copyright (C) 2011 Konstantin Shishkov

Copyright (c) 2012, Derek Buitenhuis

Copyright (c) 2015 Ludmila Glinskih

Copyright (c) 2017 Matthieu Bouron <matthieu.bouron@gmail.com>

Copyright (c) 2017 Google Inc.

Copyright (C) 2004 Romain Dolbeau <romain@dolbeau.org>

copyright (C) 2004 Marc Hoffman <marc.hoffman@analog.com>

Copyright (c) 2016 William Ma, Sofia Kim, Dustin Woo

Copyright (C) 2009 Loren Merritt <lorenm@u.washington.edu>

Copyright (C) 2014 Kieran Kunhya <kierank@obe.tv>

Copyright (C) 2015 Paul B Mahol

Copyright (C) 2012-2013 Michael Niedermayer (michaelni@gmx.at)

Copyright (C) 2011-2013 Michael Niedermayer (michaelni@gmx.at)

Copyright (C) 2011-2012 Michael Niedermayer (michaelni@gmx.at)

Copyright (c) 2012 Rob Sykes <robs@users.sourceforge.net>

Copyright (c) 2014 Luca Barbato <luzero@gentoo.org>

Copyright (c) 2014 Lukasz Marek

Copyright (c) 2014 Stefano Sabatini

Copyright (c) 2010 Nicolas George

copyright (c) 2013 Andrew Kelley

Copyright (c) 2015 Stephan Holljes

Copyright (c) 2017 Jun Zhao

Copyright (c) 2017 Kaixuan Liu

Copyright (c) 2011 Reinhard Tartler

Copyright (c) 2015 Anton Khirnov

Copyright (c) 2013-2018 Andreas Unterweger

Copyright (c) 2014 Andrey Utkin

Copyright (C) 2007 Marc Hoffman

Copyright (c) 2019 Guo Yejun

Copyright (C) 2001-2007 Michael Niedermayer

Copyright (C) 2012 Michael Niedermayer (michaelni@gmx.at)

define chromasample(a,b,c,d) (c)

elif chromaloc == 6

Copyright (c) 2011 Mans Rullgard <mans@mansr.com>

Copyright (c) 2014 Seppo Tomperi <seppo.tomperi@vtt.fi>

Copyright (c) 2001 Lionel Ulmer

Copyright (c) 2014 RISC OS Open Ltd

Copyright (c) 2002 Michael Niedermayer

Copyright (c) 2007 Siarhei Siamashka <ssvb@users.sourceforge.net>

Copyright (c) 2011 Janne Grunau <janne-libav@jannau.net>

Copyright (C) 2010 Mans Rullgard <mans@mansr.com>

Copyright (c) 2007 Luca Abeni ( lucabe72 email it )

Copyright (c) 2007 Benoit Fouet ( benoit fouet free fr )

Copyright (C) 2017 Felix Matouschek

Copyright (c) 2002 Steve O'Hara-Smith

simplegrab.c Copyright (c) 1999 Roger Hardiman

Copyright (c) 2013-2014 Ramiro Polla, Luca Barbato, Deti Fliegl

Copyright (c) 2013-2014 Ramiro Polla

Copyright (c) 2013-2014 Luca Barbato, Deti Fliegl

Copyright (c) 2014 Rafaël Carré

Copyright (c) 2014 Deti Fliegl

Copyright (c) 2010 Ramiro Polla

Copyright (c) 2015 Roger Pack

Copyright (c) 2009 Giliard B. de Freitas <giliarde@gmail.com>

Copyright (C) 2002 Gunnar Monell <gmo@linux.nu>

Copyright (c) 2013 Lukasz Marek

Copyright (C) 2013 Calvin Walton <calvin.walton@kepstin.ca>

Copyright (C) 2007-2010 Christophe Gisquet <word1.word2@gmail.com>

Copyright (c) 2012 Georg Lippitsch <georg.lippitsch@gmx.at>

Copyright (c) 2009 Samalyse

Copyright (c) 2011 Anton Khirnov <anton@khirnov.net>

Copyright (c) 2008 Alessandro Sappia

Copyright (c) 2011 Jonathan Baldwin

Copyright (c) 2011 Luca Barbato <luzero@gentoo.org>

Copyright 2004-2006 Lennart Poettering

Copyright (c) 2010 Jacob Meuser

Copyright (c) 2006 Luca Abeni

Copyright (c) 2006-2008 Ramiro Polla

Copyright (C) 2014 Luca Barbato <luzero@gentoo.org>

Copyright (c) 2013 Jeff Moguillansky

Copyright (c) 2007-2010 Stefano Sabatini

Copyright (c) 2011-2017 KO Myung-Hun <komh@chollian.net>

Copyright (c) 2012 Derek Buitenhuis

Copyright (C) 2010-2011 x264 project

Copyright (C) 1989, 1991 Free Software Foundation, Inc.,

51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

Copyright (C) 2007 Free Software Foundation, Inc. <http:fsf.org/>

Copyright (C) 1991, 1999 Free Software Foundation, Inc.

"copyright" line and a pointer to where the full notice is found.

Copyright (c) 2015 Luca Barbato <luzero@gentoo.org>

Copyright (c) 2005 Luca Barbato <luzero@gentoo.org>

Copyright 2011-2014 Twitter, Inc.

Copyright (c) 2012 Anton Khirnov

Copyright (c) 2014 Barbara Lepage <db0company@gmail.com>

**License:** LGPL V2.1

GNU Lesser General Public License

Version 2.1, February 1999

Copyright (C) 1991, 1999 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

[This is the first released version of the Lesser GPL. It also counts
as the successor of the GNU Library Public License, version 2, hence
the version number 2.1.]


Preamble

The licenses for most software are designed to take away your freedom to share and change it. By contrast, the GNU General Public Licenses are intended to guarantee your freedom to share and change free software--to make sure the software is free for all its users. 

This license, the Lesser General Public License, applies to some specially designated software packages--typically libraries--of the Free Software Foundation and other authors who decide to use it. You can use it too, but we suggest you first think carefully about whether this license or the ordinary General Public License is the better strategy to use in any particular case, based on the explanations below. 

When we speak of free software, we are referring to freedom of use, not price. Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for this service if you wish); that you receive source code or can get it if you want it; that you can change the software and use pieces of it in new free programs; and that you are informed that you can do these things.

To protect your rights, we need to make restrictions that forbid distributors to deny you these rights or to ask you to surrender these rights. These restrictions translate to certain responsibilities for you if you distribute copies of the library or if you modify it. 

For example, if you distribute copies of the library, whether gratis or for a fee, you must give the recipients all the rights that we gave you. You must make sure that they, too, receive or can get the source code. If you link other code with the library, you must provide complete object files to the recipients, so that they can relink them with the library after making changes to the library and recompiling it. And you must show them these terms so they know their rights. 

We protect your rights with a two-step method: (1) we copyright the library, and (2) we offer you this license, which gives you legal permission to copy, distribute and/or modify the library. 

To protect each distributor, we want to make it very clear that there is no warranty for the free library. Also, if the library is modified by someone else and passed on, the recipients should know that what they have is not the original version, so that the original author's reputation will not be affected by problems that might be introduced by others. 

Finally, software patents pose a constant threat to the existence of any free program. We wish to make sure that a company cannot effectively restrict the users of a free program by obtaining a restrictive license from a patent holder. Therefore, we insist that any patent license obtained for a version of the library must be consistent with the full freedom of use specified in this license. 

Most GNU software, including some libraries, is covered by the ordinary GNU General Public License. This license, the GNU Lesser General Public License, applies to certain designated libraries, and is quite different from the ordinary General Public License. We use this license for certain libraries in order to permit linking those libraries into non-free programs. 

When a program is linked with a library, whether statically or using a shared library, the combination of the two is legally speaking a combined work, a derivative of the original library. The ordinary General Public License therefore permits such linking only if the entire combination fits its criteria of freedom. The Lesser General Public License permits more lax criteria for linking other code with the library. 

We call this license the "Lesser" General Public License because it does Less to protect the user's freedom than the ordinary General Public License. It also provides other free software developers Less of an advantage over competing non-free programs. These disadvantages are the reason we use the ordinary General Public License for many libraries. However, the Lesser license provides advantages in certain special circumstances. 

For example, on rare occasions, there may be a special need to encourage the widest possible use of a certain library, so that it becomes a de-facto standard. To achieve this, non-free programs must be allowed to use the library. A more frequent case is that a free library does the same job as widely used non-free libraries. In this case, there is little to gain by limiting the free library to free software only, so we use the Lesser General Public License. 

In other cases, permission to use a particular library in non-free programs enables a greater number of people to use a large body of free software. For example, permission to use the GNU C Library in non-free programs enables many more people to use the whole GNU operating system, as well as its variant, the GNU/Linux operating system. 

Although the Lesser General Public License is Less protective of the users' freedom, it does ensure that the user of a program that is linked with the Library has the freedom and the wherewithal to run that program using a modified version of the Library. 

The precise terms and conditions for copying, distribution and modification follow. Pay close attention to the difference between a "work based on the library" and a "work that uses the library". The former contains code derived from the library, whereas the latter must be combined with the library in order to run. 

TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

0. This License Agreement applies to any software library or other program which contains a notice placed by the copyright holder or other authorized party saying it may be distributed under the terms of this Lesser General Public License (also called "this License"). Each licensee is addressed as "you".

A "library" means a collection of software functions and/or data prepared so as to be conveniently linked with application programs (which use some of those functions and data) to form executables. 

The "Library", below, refers to any such software library or work which has been distributed under these terms. A "work based on the Library" means either the Library or any derivative work under copyright law: that is to say, a work containing the Library or a portion of it, either verbatim or with modifications and/or translated straightforwardly into another language. (Hereinafter, translation is included without limitation in the term "modification".) 

"Source code" for a work means the preferred form of the work for making modifications to it. For a library, complete source code means all the source code for all modules it contains, plus any associated interface definition files, plus the scripts used to control compilation and installation of the library.

Activities other than copying, distribution and modification are not covered by this License; they are outside its scope. The act of running a program using the Library is not restricted, and output from such a program is covered only if its contents constitute a work based on the Library (independent of the use of the Library in a tool for writing it). Whether that is true depends on what the Library does and what the program that uses the Library does. 

1. You may copy and distribute verbatim copies of the Library's complete source code as you receive it, in any medium, provided that you conspicuously and appropriately publish on each copy an appropriate copyright notice and disclaimer of warranty; keep intact all the notices that refer to this License and to the absence of any warranty; and distribute a copy of this License along with the Library. 

You may charge a fee for the physical act of transferring a copy, and you may at your option offer warranty protection in exchange for a fee. 

2. You may modify your copy or copies of the Library or any portion of it, thus forming a work based on the Library, and copy and distribute such modifications or work under the terms of Section 1 above, provided that you also meet all of these conditions: 

a) The modified work must itself be a software library. 

b) You must cause the files modified to carry prominent notices stating that you changed the files and the date of any change.

c) You must cause the whole of the work to be licensed at no charge to all third parties under the terms of this License. 

d) If a facility in the modified Library refers to a function or a table of data to be supplied by an application program that uses the facility, other than as an argument passed when the facility is invoked, then you must make a good faith effort to ensure that, in the event an application does not supply such function or table, the facility still operates, and performs whatever part of its purpose remains meaningful. 

(For example, a function in a library to compute square roots has a purpose that is entirely well-defined independent of the application. Therefore, Subsection 2d requires that any application-supplied function or table used by this function must be optional: if the application does not supply it, the square root function must still compute square roots.) 

These requirements apply to the modified work as a whole. If identifiable sections of that work are not derived from the Library, and can be reasonably considered independent and separate works in themselves, then this License, and its terms, do not apply to those sections when you distribute them as separate works. But when you distribute the same sections as part of a whole which is a work based on the Library, the distribution of the whole must be on the terms of this License, whose permissions for other licensees extend to the entire whole, and thus to each and every part regardless of who wrote it. 

Thus, it is not the intent of this section to claim rights or contest your rights to work written entirely by you; rather, the intent is to exercise the right to control the distribution of derivative or collective works based on the Library. 

In addition, mere aggregation of another work not based on the Library with the Library (or with a work based on the Library) on a volume of a storage or distribution medium does not bring the other work under the scope of this License. 

3. You may opt to apply the terms of the ordinary GNU General Public License instead of this License to a given copy of the Library. To do this, you must alter all the notices that refer to this License, so that they refer to the ordinary GNU General Public License, version 2, instead of to this License. (If a newer version than version 2 of the ordinary GNU General Public License has appeared, then you can specify that version instead if you wish.) Do not make any other change in these notices. 

Once this change is made in a given copy, it is irreversible for that copy, so the ordinary GNU General Public License applies to all subsequent copies and derivative works made from that copy. 

This option is useful when you wish to copy part of the code of the Library into a program that is not a library. 

4. You may copy and distribute the Library (or a portion or derivative of it, under Section 2) in object code or executable form under the terms of Sections 1 and 2 above provided that you accompany it with the complete corresponding machine-readable source code, which must be distributed under the terms of Sections 1 and 2 above on a medium customarily used for software interchange. 

If distribution of object code is made by offering access to copy from a designated place, then offering equivalent access to copy the source code from the same place satisfies the requirement to distribute the source code, even though third parties are not compelled to copy the source along with the object code.

5. A program that contains no derivative of any portion of the Library, but is designed to work with the Library by being compiled or linked with it, is called a "work that uses the Library". Such a work, in isolation, is not a derivative work of the Library, and therefore falls outside the scope of this License. 

However, linking a "work that uses the Library" with the Library creates an executable that is a derivative of the Library (because it contains portions of the Library), rather than a "work that uses the library". The executable is therefore covered by this License. Section 6 states terms for distribution of such executables. 

When a "work that uses the Library" uses material from a header file that is part of the Library, the object code for the work may be a derivative work of the Library even though the source code is not. Whether this is true is especially significant if the work can be linked without the Library, or if the work is itself a library. The threshold for this to be true is not precisely defined by law. 

If such an object file uses only numerical parameters, data structure layouts and accessors, and small macros and small inline functions (ten lines or less in length), then the use of the object file is unrestricted, regardless of whether it is legally a derivative work. (Executables containing this object code plus portions of the Library will still fall under Section 6.) 

Otherwise, if the work is a derivative of the Library, you may distribute the object code for the work under the terms of Section 6. Any executables containing that work also fall under Section 6, whether or not they are linked directly with the Library itself. 

6. As an exception to the Sections above, you may also combine or link a "work that uses the Library" with the Library to produce a work containing portions of the Library, and distribute that work under terms of your choice, provided that the terms permit modification of the work for the customer's own use and reverse engineering for debugging such modifications. 

You must give prominent notice with each copy of the work that the Library is used in it and that the Library and its use are covered by this License. You must supply a copy of this License. If the work during execution displays copyright notices, you must include the copyright notice for the Library among them, as well as a reference directing the user to the copy of this License. Also, you must do one of these things: 

a) Accompany the work with the complete corresponding machine-readable source code for the Library including whatever changes were used in the work (which must be distributed under Sections 1 and 2 above); and, if the work is an executable linked with the Library, with the complete machine-readable "work that uses the Library", as object code and/or source code, so that the user can modify the Library and then relink to produce a modified executable containing the modified Library. (It is understood that the user who changes the contents of definitions files in the Library will not necessarily be able to recompile the application to use the modified definitions.) 

b) Use a suitable shared library mechanism for linking with the Library. A suitable mechanism is one that (1) uses at run time a copy of the library already present on the user's computer system, rather than copying library functions into the executable, and (2) will operate properly with a modified version of the library, if the user installs one, as long as the modified version is interface-compatible with the version that the work was made with. 

c) Accompany the work with a written offer, valid for at least three years, to give the same user the materials specified in Subsection 6a, above, for a charge no more than the cost of performing this distribution. 

d) If distribution of the work is made by offering access to copy from a designated place, offer equivalent access to copy the above specified materials from the same place. 

e) Verify that the user has already received a copy of these materials or that you have already sent this user a copy.

For an executable, the required form of the "work that uses the Library" must include any data and utility programs needed for reproducing the executable from it. However, as a special exception, the materials to be distributed need not include anything that is normally distributed (in either source or binary form) with the major components (compiler, kernel, and so on) of the operating system on which the executable runs, unless that component itself accompanies the executable. 

It may happen that this requirement contradicts the license restrictions of other proprietary libraries that do not normally accompany the operating system. Such a contradiction means you cannot use both them and the Library together in an executable that you distribute. 

7. You may place library facilities that are a work based on the Library side-by-side in a single library together with other library facilities not covered by this License, and distribute such a combined library, provided that the separate distribution of the work based on the Library and of the other library facilities is otherwise permitted, and provided that you do these two things: 

a) Accompany the combined library with a copy of the same work based on the Library, uncombined with any other library facilities. This must be distributed under the terms of the Sections above. 

b) Give prominent notice with the combined library of the fact that part of it is a work based on the Library, and explaining where to find the accompanying uncombined form of the same work.

8. You may not copy, modify, sublicense, link with, or distribute the Library except as expressly provided under this License. Any attempt otherwise to copy, modify, sublicense, link with, or distribute the Library is void, and will automatically terminate your rights under this License. However, parties who have received copies, or rights, from you under this License will not have their licenses terminated so long as such parties remain in full compliance. 

9. You are not required to accept this License, since you have not signed it. However, nothing else grants you permission to modify or distribute the Library or its derivative works. These actions are prohibited by law if you do not accept this License. Therefore, by modifying or distributing the Library (or any work based on the Library), you indicate your acceptance of this License to do so, and all its terms and conditions for copying, distributing or modifying the Library or works based on it. 

10. Each time you redistribute the Library (or any work based on the Library), the recipient automatically receives a license from the original licensor to copy, distribute, link with or modify the Library subject to these terms and conditions. You may not impose any further restrictions on the recipients' exercise of the rights granted herein. You are not responsible for enforcing compliance by third parties with this License. 

11. If, as a consequence of a court judgment or allegation of patent infringement or for any other reason (not limited to patent issues), conditions are imposed on you (whether by court order, agreement or otherwise) that contradict the conditions of this License, they do not excuse you from the conditions of this License. If you cannot distribute so as to satisfy simultaneously your obligations under this License and any other pertinent obligations, then as a consequence you may not distribute the Library at all. For example, if a patent license would not permit royalty-free redistribution of the Library by all those who receive copies directly or indirectly through you, then the only way you could satisfy both it and this License would be to refrain entirely from distribution of the Library. 

If any portion of this section is held invalid or unenforceable under any particular circumstance, the balance of the section is intended to apply, and the section as a whole is intended to apply in other circumstances. 

It is not the purpose of this section to induce you to infringe any patents or other property right claims or to contest validity of any such claims; this section has the sole purpose of protecting the integrity of the free software distribution system which is implemented by public license practices. Many people have made generous contributions to the wide range of software distributed through that system in reliance on consistent application of that system; it is up to the author/donor to decide if he or she is willing to distribute software through any other system and a licensee cannot impose that choice. 

This section is intended to make thoroughly clear what is believed to be a consequence of the rest of this License. 

12. If the distribution and/or use of the Library is restricted in certain countries either by patents or by copyrighted interfaces, the original copyright holder who places the Library under this License may add an explicit geographical distribution limitation excluding those countries, so that distribution is permitted only in or among countries not thus excluded. In such case, this License incorporates the limitation as if written in the body of this License. 

13. The Free Software Foundation may publish revised and/or new versions of the Lesser General Public License from time to time. Such new versions will be similar in spirit to the present version, but may differ in detail to address new problems or concerns.

Each version is given a distinguishing version number. If the Library specifies a version number of this License which applies to it and "any later version", you have the option of following the terms and conditions either of that version or of any later version published by the Free Software Foundation. If the Library does not specify a license version number, you may choose any version ever published by the Free Software Foundation. 

14. If you wish to incorporate parts of the Library into other free programs whose distribution conditions are incompatible with these, write to the author to ask for permission. For software which is copyrighted by the Free Software Foundation, write to the Free Software Foundation; we sometimes make exceptions for this. Our decision will be guided by the two goals of preserving the free status of all derivatives of our free software and of promoting the sharing and reuse of software generally. 

NO WARRANTY 

15. BECAUSE THE LIBRARY IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE LIBRARY, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE LIBRARY "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE LIBRARY IS WITH YOU. SHOULD THE LIBRARY PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. 

16. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE LIBRARY AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE LIBRARY (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE LIBRARY TO OPERATE WITH ANY OTHER SOFTWARE), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 

END OF TERMS AND CONDITIONS


How to Apply These Terms to Your New Libraries

If you develop a new library, and you want it to be of the greatest possible use to the public, we recommend making it free software that everyone can redistribute and change. You can do so by permitting redistribution under these terms (or, alternatively, under the terms of the ordinary General Public License). 

To apply these terms, attach the following notices to the library. It is safest to attach them to the start of each source file to most effectively convey the exclusion of warranty; and each file should have at least the "copyright" line and a pointer to where the full notice is found. 

one line to give the library's name and an idea of what it does.
Copyright (C) year name of author 

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

Also add information on how to contact you by electronic and paper mail. 

You should also get your employer (if you work as a programmer) or your school, if any, to sign a "copyright disclaimer" for the library, if necessary. Here is a sample; alter the names: 

Yoyodyne, Inc., hereby disclaims all copyright interest in
the library `Frob' (a library for tweaking knobs) written
by James Random Hacker.

signature of Ty Coon, 1 April 1990
Ty Coon, President of Vice

That's all there is to it! 


**Software:** YoloV3 2018.04.08

**Copyright notice:** NA

**License:** YOLO LICENSE Version 2

Version 2, July 29 2016

THIS SOFTWARE LICENSE IS PROVIDED "ALL CAPS" SO THAT YOU KNOW IT IS SUPER
SERIOUS AND YOU DON'T MESS AROUND WITH COPYRIGHT LAW BECAUSE YOU WILL GET IN
TROUBLE HERE ARE SOME OTHER BUZZWORDS COMMONLY IN THESE THINGS WARRANTIES
LIABILITY CONTRACT TORT LIABLE CLAIMS RESTRICTION MERCHANTABILITY. NOW HERE'S
THE REAL LICENSE:

0. Darknet is public domain.
1. Do whatever you want with it.
2. Stop emailing me about it!


**Software:** Deep Residual Networks 2015.12.10

**Copyright notice:** Copyright (c) 2016 Shaoqing Ren

**License:** The MIT License (MIT)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.